#8.Implement user authentication and registration in a Flask app using Flask-Login.
#url to run -